package com.demo.service.restfileservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
