package com.demo.service.restfileservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFileServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFileServiceApplication.class, args);
	}

}
